$(init);

function init()
{
    $(".home_page").attr("href","/index.php");
    $(".about_page").attr("href","/views/about.php");
    $(".products_page").attr('href',"/views/products.php");
    $(".news_page").attr("href","/views/news.php");
    $(".login_page").attr("href","/views/login.php");
    $(".signup_page").attr("href","/views/register.php");
    $(".contact_us_page").attr("href","/views/contact_us.php");
}