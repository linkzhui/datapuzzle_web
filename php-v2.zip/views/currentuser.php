<!DOCTYPE html>
<html>
<head>
	<title>current user list</title>
</head>
<body>
	<h1 text-align="center">Current Users</h1>
	<table align="center" border="2">
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
		</tr>
		<tr>
			<td>Mary</td>
			<td>Smith</td>
		</tr>
		<tr>
			<td>John</td>
			<td>Wang</td>
		</tr>
		<tr>
			<td>Alex</td>
			<td>Bington</td>
		</tr>
		<tr>
			<td>Raymond</td>
			<td>Su</td>
		</tr>

	</table>
</body>
</html>