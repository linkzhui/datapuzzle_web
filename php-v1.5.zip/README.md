# datapuzzle_web
web page for master project - datapuzzle. The web application is deployed in the AWS. 
For the frontend, I use sematic UI, html, css, javascript, ajax and jquery.
For the backend, I use php and MySQL.


Web page: http://datapuzzle.codinglinkzhui.net/
